package com.hw1.hw1;

import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final int BUTTON_REQUEST = 1;
    public static final String COLOURS = "colors";
    public String toChange;

    private MediaPlayer backgroundPlayer;
    private MediaPlayer buttonPlayer;
    static public Uri[] sound;
    public int isPlaying = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        Button button1, button2, button3;
        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChoseColorActivity.class);
                startActivityForResult(intent, 1);

            }
        });
        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChoseColorActivity.class);
                startActivityForResult(intent, 2);

            }

        });
        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChoseColorActivity.class);
                startActivityForResult(intent, 3);

            }
        });


        sound = new Uri[1];
        sound[0] = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.nein);
        buttonPlayer = new MediaPlayer();
        buttonPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        buttonPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                backgroundPlayer.pause();
                mp.start();
            }
        });
        buttonPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                backgroundPlayer.reset();
            }
        });
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "NEIN!", Snackbar.LENGTH_LONG)
                        .setAction("onResume", null).show();
//                backgroundPlayer.pause();
                if (isPlaying == 0) {
                    backgroundPlayer.start();
                    isPlaying = 1;

                } else {
                    backgroundPlayer.pause();
                    isPlaying = 0;

                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        backgroundPlayer.pause();
        buttonPlayer.pause();

    }

    @Override
    protected void onResume() {
        super.onResume();
        isPlaying = 1;
        backgroundPlayer = MediaPlayer.create(this, R.raw.nein);
        backgroundPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
                mp.start();
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        backgroundPlayer.release();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK){
            String colour = data.getStringExtra(COLOURS);
            switch(requestCode){
                case 1:
                    ((LinearLayout)(findViewById(R.id.Background))).setBackgroundColor(Color.parseColor(colour));
                    break;
                case 2:
                    (findViewById(R.id.button1)).setBackgroundColor(Color.parseColor(colour));
                    (findViewById(R.id.button2)).setBackgroundColor(Color.parseColor(colour));
                    (findViewById(R.id.button3)).setBackgroundColor(Color.parseColor(colour));
                    break;
                case 3:
                    ((Button) (findViewById(R.id.button1))).setTextColor(Color.parseColor(colour));
                    ((Button) (findViewById(R.id.button2))).setTextColor(Color.parseColor(colour));
                    ((Button) (findViewById(R.id.button3))).setTextColor(Color.parseColor(colour));
                    break;
            }
        }


    }


}
