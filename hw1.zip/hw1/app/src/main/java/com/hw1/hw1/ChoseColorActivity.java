package com.hw1.hw1;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class ChoseColorActivity extends AppCompatActivity {

    RadioButton radioButton, radioButton2, radioButton3, radioButton4, radioButton5, radioButton6;
    String selectedColour;
    Button buttonOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void onButtonOKClicked(View v) {
        radioButton = (RadioButton) findViewById(R.id.radioButton);
        radioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        radioButton3 = (RadioButton) findViewById(R.id.radioButton3);
        radioButton4 = (RadioButton) findViewById(R.id.radioButton4);
        radioButton5 = (RadioButton) findViewById(R.id.radioButton5);
        radioButton6 = (RadioButton) findViewById(R.id.radioButton6);
        if (radioButton.isChecked()) {
            selectedColour = radioButton.getText().toString();
        } else if (radioButton2.isChecked()) {
            selectedColour = radioButton2.getText().toString();
        } else if (radioButton3.isChecked()) {
            selectedColour = radioButton3.getText().toString();
        } else if (radioButton4.isChecked()) {
            selectedColour = radioButton4.getText().toString();
        } else if (radioButton5.isChecked()) {
            selectedColour = radioButton5.getText().toString();
        } else if (radioButton6.isChecked()) {
            selectedColour = radioButton6.getText().toString();
        }
        Intent data = new Intent();
        data.putExtra(MainActivity.COLOURS, selectedColour);

        setResult(RESULT_OK, data);

        finish();
    }

    public void cancel(View view) {
        Intent data = new Intent();
        setResult(RESULT_CANCELED, null);
        finish();
    }
}
